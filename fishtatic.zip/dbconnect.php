<?php 
// isi nama host, username mysql, dan password mysql anda
$conn = mysqli_connect("localhost","u1652952_fishtatic","alamsyah13","u1652952_fishtatic");

if(!$conn){
	echo "Database Connection Fail";
} else {
	
};

?>